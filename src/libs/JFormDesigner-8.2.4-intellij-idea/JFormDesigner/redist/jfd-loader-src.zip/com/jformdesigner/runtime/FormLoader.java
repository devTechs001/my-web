/*
 * Copyright (c) 2003-2011 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.runtime;

import java.beans.XMLDecoder;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.charset.UnsupportedCharsetException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import javax.xml.parsers.FactoryConfigurationError;
import com.jformdesigner.model.FormModel;

/**
 * Loads the form model from a JFormDesigner .jfd file into memory.
 * Use {@link FormCreator} to create Swing component instances.
 * <p>
 * The separation of the file loading and the component creation into two classes
 * ({@link FormLoader} and {@link FormCreator}) enables you to cache the form model
 * in memory. Using {@link FormCreator} it's possible to create multiple instances
 * of a form from one form model.
 *
 * @author Karl Tauber
 */
public class FormLoader
{
	private FormLoader() {
	}

	/**
	 * Loads a form model from the specified resource using the default
	 * class loader. Uses {@link ClassLoader#getResourceAsStream(java.lang.String)}
	 * to locate and load the form file.
	 *
	 * @param resourceName The name of the resource containing a form
	 * 		(e.g. "com/jformdesigner/examples/LoaderExample.jfd").
	 * @return The form model.
	 * @throws Exception See {@link #load(InputStream)} for details.
	 */
	public static FormModel load( String resourceName )
		throws Exception
	{
		ClassLoader classLoader = FormLoader.class.getClassLoader();
		try {
			InputStream in = classLoader.getResourceAsStream( resourceName );
			if( in == null ) {
				// resource not found --> try classloader of invoker
				// (required when a custom bean uses FormLoader in JFormDesigner)
				Class<?>[] stack = new ContextGetter().getClassContext();
				classLoader = stack[2].getClassLoader();
				if( classLoader != FormLoader.class.getClassLoader() )
					in = classLoader.getResourceAsStream( resourceName );
			}
			return load( in, classLoader );
		} catch( MultiException ex ) {
			throw ex.getExceptions()[0];
		}
	}

	/**
	 * Loads a form model from the specified resource using the specified
	 * class loader. Uses {@link ClassLoader#getResourceAsStream(java.lang.String)}
	 * to locate and load the form file.
	 *
	 * @param resourceName The name of the resource containing a form
	 * 		(e.g. "com/jformdesigner/examples/LoaderExample.jfd").
	 * @param classLoader The class loader.
	 * @return The form model.
	 * @throws Exception See {@link #load(InputStream)} for details.
	 */
	public static FormModel load( String resourceName, ClassLoader classLoader )
		throws Exception
	{
		try {
			return load( classLoader.getResourceAsStream( resourceName ), classLoader );
		} catch( MultiException ex ) {
			throw ex.getExceptions()[0];
		}
	}

	/**
	 * Loads a form model from the specified file.
	 *
	 * @param file The file containing a form.
	 * @return The form model.
	 * @throws Exception See {@link #load(InputStream)} for details.
	 */
	public static FormModel load( File file )
		throws Exception
	{
		return load( new FileInputStream( file ) );
	}

	/**
	 * Loads a form model from the given input stream.
	 * Use this method if you want read a form e.g. from a database.
	 * <p>
	 * A {@link BufferedInputStream} is used to improve performance.
	 *
	 * @param in The input stream. Closed when this method returns.
	 * @return The form model.
	 * @throws IllegalArgumentException If the input stream is {@code null}.
	 * @throws IOException If an error occurred when reading from the input stream.
	 * @throws SAXParseException If an error occurred when parsing the XML content.
	 * @throws ClassNotFoundException If a class used in the XML content is not found.
	 * @throws ClassCastException If the root object in the XML content is not a {@link FormModel}.
	 * @throws Exception If an other error occurred when decoding the XML content.
	 */
	public static FormModel load( InputStream in )
		throws Exception
	{
		try {
			return load( in, null );
		} catch( MultiException ex ) {
			throw ex.getExceptions()[0];
		}
	}

	/**
	 * Loads a form model from the given input stream.
	 * Use this method if you want read a form e.g. from a database.
	 * <p>
	 * A {@link BufferedInputStream} is used to improve performance.
	 *
	 * @param in The input stream. Closed when this method returns.
	 * @param classLoader The class loader used to load classes.
	 * @return The form model.
	 * @throws IllegalArgumentException If the input stream is {@code null}.
	 * @throws MultiException If a problem occurred when encoding the form model to XML.
	 * @throws ClassCastException If the root object in the XML content is not a {@link FormModel}.
	 *
	 * @since 1.0.1
	 */
	public static FormModel load( InputStream in, ClassLoader classLoader )
		throws MultiException
	{
		if( in == null )
			throw new IllegalArgumentException( "Input stream is null." );

		byte[] bytes;
		try {
			bytes = readResource( in );
		} catch( IOException ex ) {
			throw new MultiException( "Failed to read form file.", new Exception[] { ex } );
		}

		if( bytes.length == 0 )
			throw new MultiException( "Form file is empty.", null );

		Thread currentThread = Thread.currentThread();
		ClassLoader oldContextClassLoader = null;
		if( classLoader != null ) {
			oldContextClassLoader = currentThread.getContextClassLoader();
			currentThread.setContextClassLoader( new ContextClassLoader( classLoader, oldContextClassLoader ) );
		}

		try {
			boolean isXML = (bytes[0] == '<');
			fixJGoodiesBorders( bytes, isXML );

			InputStream bin = new ByteArrayInputStream( bytes );

			Object result;
			Map<String, String> headerAttributes = Collections.emptyMap();
			FormPersistenceExceptionListener exceptionListener = new FormPersistenceExceptionListener();

			if( isXML ) {
				try( XMLDecoder decoder = new XMLDecoder( bin, null, exceptionListener ) ) {
					result = decoder.readObject();
				}
			} else {
				try( JFDMLDecoder decoder = new JFDMLDecoder( bin, null, exceptionListener, null ) ) {
					decoder.setClassNameMapper( FormPersistenceClassNameMapper.getInstance() );
					result = decoder.readObject();
					headerAttributes = decoder.getHeaderAttributes();
				}
			}

			Exception[] exceptions = exceptionListener.getExceptions();
			if( exceptions != null ) {
				throw new MultiException( "Failed to decode.",
					(result instanceof FormModel) ? ((FormModel)result).getContentType() : null,
					exceptions );
			}

			String encoding = headerAttributes.get( "encoding" );

			FormModel model = (FormModel) result;
			if( classLoader != null )
				model.set_ClassLoader( classLoader );
			model.putClientProperty( "format", isXML ? "XML" : "JFDML" );
			model.putClientProperty( "encoding", encoding );
			model.putClientProperty( "JFormDesigner", headerAttributes.get( "JFormDesigner" ) );
			model.putClientProperty( "Java", headerAttributes.get( "Java" ) );
			model.putClientProperty( "headerComment", isXML
				? getHeaderComment( bytes, "\n<!--", "-->", encoding )
				: getHeaderComment( bytes, "\n/*", "*/", encoding ) );
			return model;

		} catch( FactoryConfigurationError ex ) {
			// may be thrown by XMLDecoder.readObject()
			throw new MultiException( "Failed to decode.",
				new Exception[] { new InvocationTargetException( ex ) } );
		} finally {
			if( classLoader != null )
				currentThread.setContextClassLoader( oldContextClassLoader );
		}
	}

	private static byte[] readResource( InputStream in )
		throws IOException
	{
		try( InputStream in2 = in ) {
			byte[] buffer = new byte[in2.available()];
			int length = 0;
			for(;;) {
				int n = in2.read( buffer, length, buffer.length - length );
				if( n < 0 ) {
					if( length == buffer.length )
						return buffer;

					// shrink buffer
					return copyBuffer( buffer, length );
				}

				length += n;
				if( length == buffer.length ) {
					// check whether available() returned the correct size
					int last = in2.read();
					if( last < 0 )
						return buffer;

					// increase buffer size and continue reading
					buffer = copyBuffer( buffer, length + 5000 );

					buffer[length++] = (byte) last;
				}
			}
		}
	}

	private static byte[] copyBuffer( byte[] buffer, int newLength ) {
		byte[] newBuffer = new byte[newLength];
		System.arraycopy( buffer, 0, newBuffer, 0, Math.min( newLength, buffer.length ) );
		return newBuffer;
	}

	private static String getHeaderComment( byte[] bytes, String start, String end, String encoding ) {
		Charset charset = StandardCharsets.UTF_8;
		if( encoding != null ) {
			try {
				charset = Charset.forName( encoding );
			} catch( UnsupportedCharsetException ex ) {
				// use UTF-8
			}
		}

		int commentStart = indexOf( bytes, start.getBytes( charset ), 0 );
		if( commentStart < 0 )
			return null;

		int commentEnd = indexOf( bytes, end.getBytes( charset ), commentStart + 4 );
		if( commentEnd < 0 )
			return null;

		commentStart += start.length();

		while( bytes[commentStart] == '\n' || bytes[commentStart] == '\r' )
			commentStart++;
		while( bytes[commentEnd - 1] == '\n' || bytes[commentEnd - 1] == '\r' )
			commentEnd--;

		return new String( bytes, commentStart, commentEnd - commentStart, charset );
	}

	private static int indexOf( byte[] bytes, byte[] strBytes, int fromIndex ) {
		byte firstStrByte = strBytes[0];
		int length = bytes.length - strBytes.length + 1;
		for( int i = fromIndex; i < length; i++ ) {
			if( bytes[i] == firstStrByte && equals( bytes, i, strBytes, 0, strBytes.length ) )
				return i;
		}
		return -1;
	}

	private static boolean equals( byte[] bytes1, int offset1, byte[] bytes2, int offset2, int length ) {
		if( offset1 + length > bytes1.length || offset2 + length > bytes2.length )
			return false;

		for( int i = 0; i < length; i++ ) {
			if( bytes1[offset1 + i] != bytes2[offset2 + i] )
				return false;
		}
		return true;
	}

	/**
	 * Since JGoodies Forms 1.7 the names of the predefined borders in class
	 * com.jgoodies.forms.factories.Borders have changed, which causes errors
	 * while loading forms that use such borders.
	 *
	 * This method checks the JGoodies Forms version and renames the borders if necessary.
	 *
	 * For backward compatibility, always old border names are stored in forms.
	 */
	private static void fixJGoodiesBorders( byte[] bytes, boolean isXML ) {
		if( indexOf( bytes, "com.jgoodies.forms.factories.Borders".getBytes( StandardCharsets.UTF_8 ), 0 ) < 0 )
			return; // form does not use JGoodies borders

		try {
			Class<?> bordersClass = Class.forName( "com.jgoodies.forms.factories.Borders" );
			bordersClass.getField( "EMPTY_BORDER" );
			return; // we are running JGoodies Forms 1.6 or older
		} catch( NoSuchFieldException ex ) {
			// we are running JGoodies Forms 1.7+
		} catch( Exception ex ) {
			return;
		}

		byte[] searchBegin = (isXML
			? "<object class=\"com.jgoodies.forms.factories.Borders\" field=\""
			: " sfield com.jgoodies.forms.factories.Borders ")
			.getBytes(StandardCharsets.UTF_8);
		byte[] searchEnd = (isXML ? "\"/>" : "").getBytes( StandardCharsets.UTF_8 );

		String[] borderNamesStr = {
			"EMPTY_BORDER",			"EMPTY",
			"DLU2_BORDER",			"DLU2",
			"DLU4_BORDER",			"DLU4",
			"DLU7_BORDER",			"DLU7",
			"DLU14_BORDER",			"DLU14",
			"DLU21_BORDER",			"DLU21",
			"BUTTON_BAR_GAP_BORDER",	"BUTTON_BAR_PAD",
			"DIALOG_BORDER",			"DIALOG",
			"TABBED_DIALOG_BORDER",	"TABBED_DIALOG",
		};
		byte[][] borderNames = new byte[borderNamesStr.length][];
		for( int i = 0; i < borderNamesStr.length; i++ )
			borderNames[i] = borderNamesStr[i].getBytes( StandardCharsets.UTF_8 );

		int fromIndex = 0;
		int index;
		while( (index = indexOf( bytes, searchBegin, fromIndex )) >= 0 ) {
			int nameIndex = index + searchBegin.length;
			for( int i = 0; i < borderNames.length; i += 2 ) {
				byte[] oldBorderName = borderNames[i];
				if( equals( bytes, nameIndex, oldBorderName, 0, oldBorderName.length ) &&
					equals( bytes, nameIndex + oldBorderName.length, searchEnd, 0, searchEnd.length ) )
				{
					// found
					byte[] newBorderName = borderNames[i+1];
					System.arraycopy( newBorderName, 0, bytes, nameIndex, newBorderName.length );
					System.arraycopy( searchEnd, 0, bytes, nameIndex + newBorderName.length, searchEnd.length );
					Arrays.fill( bytes, nameIndex + newBorderName.length + searchEnd.length,
						nameIndex + oldBorderName.length + searchEnd.length, (byte) ' ' );
					break;
				}
			}

			fromIndex = nameIndex;
		}
	}

	//---- class ContextGetter ------------------------------------------------

	/**
	 * Used to make a protected method public.
	 */
	private static final class ContextGetter
		extends SecurityManager
	{
		@Override
		public Class<?>[] getClassContext() {
			return super.getClassContext();
		}
	}

	//---- class ContextClassLoader -------------------------------------------

	/**
	 * This class loader is necessary in rare cases where a XML library
	 * (e.g. xercesImpl.jar) is in the lib/ext folder of the JRE, but the
	 * given form class loader (e.g. a Eclipse plug-in class loader) does
	 * not find classes from the lib/ext folder.
	 *
	 * Without this class loader, a "javax.xml.parsers.FactoryConfigurationError:
	 * Provider org.apache.xerces.jaxp.SAXParserFactoryImpl not found" is
	 * thrown in the above scenario (xercesImpl.jar and Eclipse) because
	 * javax.xml.parsers.FactoryFinder.findJarServiceProvider() finds the file
	 * "META-INF/services/javax.xml.parsers.SAXParserFactory" from xercesImpl.jar
	 * (using the ClassLoader.getSystemResourceAsStream()), but
	 * FactoryFinder.newInstance() can not find the class (because classLoader is null).
	 *
	 * This class loader therefore delegates to the old context class loader.
	 *
	 * @since 3.1
	 */
	private static class ContextClassLoader
		extends ClassLoader
	{
		private final ClassLoader oldContextClassLoader;

		ContextClassLoader( ClassLoader classLoader, ClassLoader oldContextClassLoader ) {
			super( classLoader );
			this.oldContextClassLoader = oldContextClassLoader;
		}

		@Override
		protected Class<?> findClass( String name )
			throws ClassNotFoundException
		{
			try {
				return getParent().loadClass( name );
			} catch( ClassNotFoundException ex ) {
				try {
					return oldContextClassLoader.loadClass( name );
				} catch( ClassNotFoundException ex2 ) {
					// throw original exception
					throw ex;
				}
			}
		}

		@Override
		public URL getResource( String name ) {
			URL url = super.getResource( name );
			if( url == null && oldContextClassLoader != null )
				url = oldContextClassLoader.getResource( name );
			return url;
		}
	}
}
