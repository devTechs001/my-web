/*
 * Copyright (c) 2011 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.runtime;

import java.util.HashMap;

/**
 * @author Karl Tauber
 * @since 5.1
 */
class FormPersistenceClassNameMapper
	implements JFDMLClassNameMapper
{
	private static final String MODEL_PACKAGE = "com.jformdesigner.model.";
	private static final String[] MODEL_CLASSES = {
		"FormBinding",
		"FormBindingGroup",
		"FormComponent",
		"FormContainer",
		"FormEvent",
		"FormLayoutConstraints",
		"FormLayoutManager",
		"FormMessage",
		"FormMessageArray",
		"FormModel",
		"FormNonVisual",
		"FormReference",
		"FormRoot",
		"FormWindow",
	};

	private static final String ESCAPE_SUFFIX = "__$$";

	private static FormPersistenceClassNameMapper instance;

	private final HashMap<String, String> shortToFullClassNameMap = new HashMap<>();
	private final HashMap<String, String> fullToShortClassNameMap = new HashMap<>();

	static synchronized FormPersistenceClassNameMapper getInstance() {
		if( instance == null )
			instance = new FormPersistenceClassNameMapper();
		return instance;
	}

	protected FormPersistenceClassNameMapper() {
		for( String shortClassName : MODEL_CLASSES ) {
			String fullClassName = MODEL_PACKAGE.concat( shortClassName );
			shortToFullClassNameMap.put( shortClassName, fullClassName );
			fullToShortClassNameMap.put( fullClassName, shortClassName );
		}
	}

	@Override
	public String encode( String className ) {
		String shortClassName = fullToShortClassNameMap.get( className );
		if( shortClassName != null )
			return shortClassName;

		if( shortToFullClassNameMap.containsKey( className ) )
			return className.concat( ESCAPE_SUFFIX );

		return className;
	}

	@Override
	public String decode( String className ) {
		String fullClassName = shortToFullClassNameMap.get( className );
		if( fullClassName != null )
			return fullClassName;

		if( className.endsWith( ESCAPE_SUFFIX ) )
			return className.substring( 0, className.length() - ESCAPE_SUFFIX.length() );

		return className;
	}
}
